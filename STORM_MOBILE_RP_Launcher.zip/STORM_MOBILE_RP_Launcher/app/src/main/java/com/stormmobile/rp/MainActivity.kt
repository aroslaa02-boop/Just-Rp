package com.stormmobile.rp

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 13, 27)
    private val panel = Color.rgb(17, 27, 49)
    private val accent = Color.rgb(55, 145, 255)
    private val muted = Color.rgb(166, 184, 211)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
        showHome()
    }

    private fun showHome() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(30), dp(22), dp(28))
        }

        val logo = TextView(this).apply {
            text = "STORM"
            textSize = 38f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
            letterSpacing = 0.16f
        }
        page.addView(logo, matchWrap())

        val subtitle = TextView(this).apply {
            text = "MOBILE ROLEPLAY"
            textSize = 12f
            setTextColor(accent)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            letterSpacing = 0.28f
        }
        page.addView(subtitle, matchWrap())
        addSpace(page, 28)

        val status = TextView(this).apply {
            text = "●  ЛАУНЧЕР ЗАПУЩЕН"
            textSize = 12f
            setTextColor(Color.rgb(90, 220, 155))
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        page.addView(status, matchWrap())
        addSpace(page, 18)

        val play = makeButton("ИГРАТЬ", accent)
        page.addView(play, matchWidth(58))
        play.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("STORM MOBILE RP")
                .setMessage("Игровой клиент пока не подключён. Этот APK — лаунчер. Для входа на сервер понадобится совместимый мобильный игровой клиент.")
                .setPositiveButton("ПОНЯТНО", null)
                .show()
        }
        addSpace(page, 14)

        val settings = makeButton("НАСТРОЙКИ", panel)
        page.addView(settings, matchWidth(52))
        settings.setOnClickListener { showSettings() }
        addSpace(page, 28)

        addSectionTitle(page, "ПОСЛЕДНИЕ НОВОСТИ")
        addSpace(page, 10)
        addNews(page, "Добро пожаловать в STORM", "Мы готовим проект. Следи за обновлениями лаунчера.")
        addNews(page, "Разработка продолжается", "Новые функции и игровые системы будут добавляться постепенно.")
        addSpace(page, 18)

        val footer = TextView(this).apply {
            text = "STORM MOBILE RP  •  VERSION 0.1.0"
            textSize = 10f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        page.addView(footer, matchWrap())
        scroll.addView(page)
        setContentView(scroll)
    }

    private fun showSettings() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(8))
        }
        val info = TextView(this).apply {
            text = "Версия лаунчера: 0.1.0\n\nСервер: пока не подключён\n\nУведомления и выбор сервера появятся в следующих версиях."
            textSize = 15f
            setTextColor(Color.WHITE)
        }
        content.addView(info)
        AlertDialog.Builder(this)
            .setTitle("НАСТРОЙКИ")
            .setView(content)
            .setPositiveButton("ГОТОВО", null)
            .show()
    }

    private fun addSectionTitle(parent: LinearLayout, title: String) {
        val view = TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0.06f
        }
        parent.addView(view, matchWrap())
    }

    private fun addNews(parent: LinearLayout, title: String, body: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(panel, 16)
        }
        val heading = TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val description = TextView(this).apply {
            text = body
            textSize = 13f
            setTextColor(muted)
            setPadding(0, dp(7), 0, 0)
        }
        card.addView(heading, matchWrap())
        card.addView(description, matchWrap())
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.bottomMargin = dp(10)
        parent.addView(card, lp)
    }

    private fun makeButton(label: String, color: Int): Button =
        Button(this).apply {
            text = label
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            isAllCaps = false
            background = rounded(color, 14)
            stateListAnimator = null
        }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun matchWidth(height: Int) = LinearLayout.LayoutParams(-1, dp(height))
}
