# STORM MOBILE RP — Android Launcher

This repository contains a starter Android launcher app for STORM MOBILE RP.

## Build
A push to `main` starts GitHub Actions. The workflow builds a debug APK and uploads it as an artifact named `STORM-MOBILE-RP-debug`.

The current launcher contains:
- STORM branding and a home screen
- Play button (shows a notice because no game client is connected yet)
- News cards
- Settings dialog

Important: this is only the launcher shell. It does not include GTA San Andreas, a multiplayer client, server connectivity, or game assets. Those require a separately licensed and compatible game/client setup.
